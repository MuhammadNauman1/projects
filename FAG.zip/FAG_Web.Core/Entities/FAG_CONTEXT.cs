﻿using FAG_Web.Core.Entities.Model.Account;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static FAG_Web.Core.Entities.Model.Account.Models;

namespace FAG_Web.Core.Entities
{
    public class FAG_CONTEXT:DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Aim> Aims { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<SubCategory> Subcategories { get; set; }
        public DbSet<Caution> Cautions { get; set; }
        public DbSet<Image> Images { get; set; }
        public DbSet<CategoryImage> CategoryImages { get; set; }
        public DbSet<Video> Videos { get; set; }
        public DbSet<WhatToDo> Whattodos { get; set; }
        public DbSet<Recognition> Recognitions { get; set; }
        public DbSet<Emergency> Emergencies { get; set; }
        public DbSet<EmergencyNumber> EmergencyNumbers { get; set; }
        public FAG_CONTEXT(DbContextOptions<FAG_CONTEXT> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>()
                .HasMany(p => p.SubCategory).WithOne();
            modelBuilder.Query<HomeData>();
            modelBuilder.Query<SubCatData>();
        }
        public  IQueryable<HomeData> GetHomeData()
        {
            try
            {
               return Query<HomeData>().FromSql("FAG_PROC_GET_HOME_DATA");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public IQueryable<SubCatData> GetSubCatData(int catId)
        {
            try
            {
                return Query<SubCatData>().FromSql("EXEC FAG_PROC_GET_SUB_CATEGORIES @CATID='" + catId+"'");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
