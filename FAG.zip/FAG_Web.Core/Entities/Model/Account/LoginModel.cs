﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace FAG_Web.Core.Entities.Model.Account
{
   public  class LoginModel
    {
        [Required(ErrorMessage ="Username is required."),RegularExpression(".{5,20}",ErrorMessage ="")]
        public string Username { get; set; }
        [Required(ErrorMessage ="Password is required."),RegularExpression("[A-Za-z0-9@\\.]{4,8}", ErrorMessage ="")]
        public string Password { get; set; }
    }
}
