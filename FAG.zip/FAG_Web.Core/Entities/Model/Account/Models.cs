﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace FAG_Web.Core.Entities.Model.Account
{
    public class Models
    {

        [Table("AIM")]
        public class Aim:DefaultConstraint
        {
            [Key(),Column("ID")]
            public int Id { get; set; }

            [Column("DESCRIPTION")]
            public string Description { get; set; }
            [Column("ITEMID")]
            public int? Itemid { get; set; }
        }

        [Table("CATEGORY")]
        public class Category : DefaultConstraint
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("NAME")]
            public string Name { get; set; }
            public List<SubCategory> SubCategory { get; set; }
        }

        [Table("CAUTION")]
        public class Caution : DefaultConstraint
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("DESCRIPTION")]
            public string Description { get; set; }

            [Column("ITEMID")]
            public int? Itemid { get; set; }
        }

        [Table("IMAGE")]
        public class Image : DefaultConstraint
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("URL")]
            public string Url { get; set; }
        }

        [Table("ITEM")]
        public class Item : DefaultConstraint
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("DESCRIPTION")]
            public string Description { get; set; }
            
            [Column("CATEGORYID")]
            public int? Categoryid { get; set; }

            [Column("SUBCATEGORYID")]
            public int? Subcategoryid { get; set; }
            public IList<Aim> Aims { get; set; } = new List<Aim>();
            public IList<Caution> Cautions { get; set; } = new List<Caution>();
            public IList<Image> Images { get; set; } = new List<Image>();
            public IList<Video> Videos { get; set; } = new List<Video>();
            public IList<WhatToDo> Whattodos { get; set; } = new List<WhatToDo>();
            public IList<Recognition> Recognitions { get; set; } = new List<Recognition>();
        }

        [Table("REGONITION")]
        public class Recognition : DefaultConstraint
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("DESCRIPTION")]
            public string Description { get; set; }

            [Column("ITEMID")]
            public int? Itemid { get; set; }
        }

        [Table("SUBCATEGORY")]
        public class SubCategory : DefaultConstraint
        {
            [Key()]
            [Column("ID")]
            public int Id { get; set; }

            [Column("NAME")]
            public string Name { get; set; }

            [Column("CATEGORYID")]
            public int? Categoryid { get; set; }
        
        }

        [Table("VIDEO")]
        public class Video : DefaultConstraint
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("URL")]
            public string Url { get; set; }
            
            [Column("ITEMID")]
            public int? Itemid { get; set; }
        }

        [Table("WHATTODO")]
        public class WhatToDo : DefaultConstraint
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("DESCRIPTION")]
            public string Description { get; set; }

            [Column("ITEMID")]
            public int? Itemid { get; set; }
        }

        [Table("EMERGENCY")]
        public class Emergency
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("DESCRIPTION")]
            public string Description { get; set; }

            [Column("CREATEDDATE")]
            public DateTime? Createddate { get; set; }

            [Column("CREATEDBY")]
            public int? Createdby { get; set; }

            [Column("MODIFIEDDATE")]
            public DateTime? Modifieddate { get; set; }

            [Column("MODIFIEDBY")]
            public int? Modifiedby { get; set; }

            [Column("DELETED")]
            public bool? Deleted { get; set; }

            [Column("CITY")]
            public string City { get; set; }
        }

        [Table("EMERGENCYNUMBER")]
        public class EmergencyNumber
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("DESCRIPTION")]
            public string Description { get; set; }

            [Column("NUMBER")]
            public string Number { get; set; }

            [Column("CREATEDDATE")]
            public DateTime? Createddate { get; set; }

            [Column("CREATEDBY")]
            public int? Createdby { get; set; }

            [Column("MODIFIEDDATE")]
            public DateTime? Modifieddate { get; set; }

            [Column("MODIFIEDBY")]
            public int? Modifiedby { get; set; }

            [Column("DELETED")]
            public bool? Deleted { get; set; }

            [Column("EMERGENCYID")]
            public int? Emergencyid { get; set; }
        }

        [Table("CATEGORYIMAGE")]
        public class CategoryImage:DefaultConstraint
        {
            [Column("ID")]
            public int Id { get; set; }

            [Column("CATID")]
            public int? CatId { get; set; }

            [Column("IMAGEID")]
            public int? ImageId { get; set; }

            [Column("SUBCATID")]
            public int? SubcatId { get; set; }

            [Column("STEPID")]
            public int? StepId { get; set; }
        }

        public class EmergencyInfo
        {
            public Emergency Emergencies { get; set; }
            public List<EmergencyNumber> EmergencyNumbers { get; set; }
        }
        public class HomeData
        {
            public string Topic { get; set; }
            public string URL { get; set; }
            public int CategoryId { get; set; }
            public int ImageId { get; set; }
        }
        public class SubCatData
        {
            public int catId { get; set; }
            public int subCatId { get; set; }
            public string subCatName { get; set; }
            public string url { get; set; }
        }
    }
}
