﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace FAG_Web.Core.Entities.Model.Account
{
    [Table("USER")]
    public class User:DefaultConstraint
    {
        [Key()]
        [Column("ID")]
        public int Id { get; set; }
        [Column("FIRSTNAME")]
        public string FirstName { get; set; }
        [Column("LASTNAME")]
        public string LastName { get; set; }
        [Column("USERNAME")]
        public string Username { get; set; }
        [Column("PASSWORD")]
        public string Password { get; set; }
        [Column("TYPE")]
        public string UserType { get; set; }
        [Column("IMAGE")]
        public string Image { get; set; }

    }

}
