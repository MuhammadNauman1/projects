﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FAG_Web.Core.Entities.Model
{
    public class DefaultConstraint
    {
        [Column("CREATEDBY")]
        public virtual string CreatedBy { get; set; }
        [Column("CREATEDDATE")]
        public virtual DateTime? CreatedDate { get; set; }
        [Column("MODIFIEDBY")]
        public virtual string ModifiedBy { get; set; }
        [Column("MODIFIEDDATE")]
        public virtual DateTime? ModifiedDate { get; set; }
        [Column("DELETED")]
        public virtual bool? Deleted { get; set; }
    }
}
