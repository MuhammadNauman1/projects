﻿using FAG_Web.Core.Entities.Model.Account;
using System;
using System.Collections.Generic;
using System.Text;

namespace FAG_Web.Core.Interfaces.Account
{
    public interface IAccount
    {
        User Login(LoginModel model);
        //User GetUserData(LoginModel model);
    }
}
