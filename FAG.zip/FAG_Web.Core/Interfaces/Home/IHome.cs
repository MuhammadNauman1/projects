﻿using System;
using System.Collections.Generic;
using System.Text;
using static FAG_Web.Core.Entities.Model.Account.Models;

namespace FAG_Web.Core.Interfaces.Home
{
    public interface IHome
    {
        List<Category> GetCategories();
        List<Item> GetItemsAll();
        Item GetItem(int? catId, int? subCatId);
        List<EmergencyInfo> GetEmergencyInfo(string city);
        List<HomeData> GetHomeData();
        List<SubCatData> GetSubCategoriesData(int catId);
        void AddItem(Item item);

    }
}
