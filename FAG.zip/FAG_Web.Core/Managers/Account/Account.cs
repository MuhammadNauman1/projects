﻿using FAG_Web.Core.Entities;
using FAG_Web.Core.Entities.Model.Account;
using FAG_Web.Core.Interfaces.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FAG_Web.Core.Managers.Account
{
    public class Account : IAccount
    {
        private readonly FAG_CONTEXT db;
        public Account(FAG_CONTEXT _db)
        {
            db = _db;
        }
        public User Login(LoginModel model)
        {
            try
            {
                var user=db.Users.FirstOrDefault(x => x.Deleted != true && x.Username.ToUpper() == model.Username.ToUpper() && x.Password == model.Password);
                if (user!=null)
                {
                    return user;
                }
                else
                {
                    throw new Exception("Login failed. Username or Password is not correct");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
