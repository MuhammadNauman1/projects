﻿using FAG_Web.Core.Entities;
using FAG_Web.Core.Entities.Model.Account;
using FAG_Web.Core.Interfaces.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static FAG_Web.Core.Entities.Model.Account.Models;

namespace FAG_Web.Core.Managers.Home
{

    public class Home : IHome
    {
        private readonly FAG_CONTEXT db;
        public Home(FAG_CONTEXT _db)
        {
            db = _db;
        }

        public void AddItem(Item item)
        {
            try
            {
                db.Items.Add(item);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Category> GetCategories()
        {
            try
            {
                var categories = db.Categories;
                foreach (var item in categories)
                {
                    item.SubCategory = db.Subcategories.Where(x => x.Categoryid == item.Id).ToList();
                }

                return categories.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<EmergencyInfo> GetEmergencyInfo(string city)
        {
            try
            {
                var returnData = new List<EmergencyInfo>();
                var result = db.Emergencies.Where(x => x.City.ToLower() == city.ToLower()).ToList();
                foreach (var item in result)
                {
                    var numbers = db.EmergencyNumbers.Where(x => x.Emergencyid == item.Id).ToList();
                    returnData.Add(
                        new EmergencyInfo
                        {
                            Emergencies = item,
                            EmergencyNumbers = numbers
                        }
                        );
                }
                return returnData;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<HomeData> GetHomeData()
        {
            try
            {
                return db.GetHomeData().ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Item GetItem(int? catId, int? subCatId)
        {
            try
            {
                Item item = null;
                if (subCatId == null)
                {
                    item = db.Items.FirstOrDefault(x => x.Categoryid == catId);
                }
                if (subCatId != null)
                {
                    var subcatid = db.Subcategories.FirstOrDefault(x => x.Id == subCatId);
                    if (subcatid!=null)
                    {
                    item = db.Items.FirstOrDefault(x =>x.Categoryid==subcatid.Categoryid);

                    }
                    else
                    {
                        item = new Item();
                    }
                }
                if (item!=null)
                {
                    item.Aims = db.Aims.Where(x => x.Itemid == item.Id).ToList();
                    item.Cautions = db.Cautions.Where(x => x.Itemid == item.Id).ToList();
                    item.Images = db.Images.ToList();/////// ; (from img in db.Images join ci in db.CategoryImages on img.Id equals ci.ImageId select img).ToList(); ;//db.Images.Join(db.CategoryImages, (images, catImages) => { })
                    item.Videos = db.Videos.Where(x => x.Itemid == item.Id).ToList();
                    item.Whattodos = db.Whattodos.Where(x => x.Itemid == item.Id).ToList();
                    item.Recognitions = db.Recognitions.Where(x => x.Itemid == item.Id).ToList(); 
                }

                return item;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Item> GetItemsAll()
        {
            try
            {
                var items = db.Items;
                foreach (var item in items)
                {
                    item.Aims = db.Aims.Where(x => x.Itemid == item.Id).ToList();
                    item.Cautions = db.Cautions.Where(x => x.Itemid == item.Id).ToList();
                    //item.Images = db.Images.Where(x => x.Itemid == item.Id).ToList();
                    item.Videos = db.Videos.Where(x => x.Itemid == item.Id).ToList();
                    item.Whattodos = db.Whattodos.Where(x => x.Itemid == item.Id).ToList();
                    item.Recognitions = db.Recognitions.Where(x => x.Itemid == item.Id).ToList();
                }
                return items.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<SubCatData> GetSubCategoriesData(int catId)
        {
            try
            {
                return db.GetSubCatData(catId).ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
