﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FAG_Web.Core.Entities.Model.Account;
using FAG_Web.Core.Interfaces.Account;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace FAG_Web.Controllers.Accounts
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private IAccount Account;
        public AccountController(IAccount _account)
        {
            Account = _account;
        }
        [HttpPost,Route("Login")]
        public IActionResult Login([FromBody]LoginModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var user=Account.Login(model);
                if (user!=null)
                {
                    user.Password = "";
                    HttpContext.Session.SetString("user",JsonConvert.SerializeObject(user));
                    return Ok(user);
                }
                else
                {
                    return BadRequest("Request failed");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet,Route("GetUserData")]
        public IActionResult GetUserData()
        {
            try
            {
                var userSession=HttpContext.Session.Keys.FirstOrDefault(x => x == "user");
                if (userSession==null)
                {
                    return BadRequest("logout");
                }
                else
                {

                    return Ok(JsonConvert.DeserializeObject<User>(HttpContext.Session.GetString("user")));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet,Route("Logout")]
        public IActionResult Logout()
        {
            try
            {
                HttpContext.Session.Clear();
                return Ok("loggedout");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}