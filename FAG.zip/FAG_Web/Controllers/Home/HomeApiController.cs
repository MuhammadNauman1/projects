﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using FAG_Web.Core.Interfaces.Home;
using static FAG_Web.Core.Entities.Model.Account.Models;

namespace FAG_Web.Controllers.Home
{
    [Route("api/Home")]
    [ApiController]
    public class HomeApiController : ControllerBase
    {
        private readonly IHome home;
        public HomeApiController(IHome _home)
        {
            home = _home;
        }
        [HttpGet, Route("GetSubCategoriesData/{catId}")]
        public IActionResult GetSubCategoriesData(int catId)
        {
            try
            {
                var data = home.GetSubCategoriesData(catId);
                if (data != null)
                    return Ok(data);
                else
                    return BadRequest("{error:'failed'}");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet, Route("Categories")]
        public IActionResult GetCategories()
        {
            try
            {
                var categories = home.GetCategories();
                if (categories != null)
                {
                    return Ok(categories);
                }
                else
                {
                    throw new Exception("Unhandled exception");
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet, Route("AllItems")]
        public IActionResult GetAllItems()
        {
            try
            {
                var categories = home.GetItemsAll();
                if (categories != null)
                {
                    var val = categories[0]?.Recognitions[0]?.Description.Replace("\r\n", "<br/>");
                    categories[0].Recognitions[0].Description = val ?? "";
                    return Ok(categories);
                }
                else
                {
                    throw new Exception("Unhandled exception");
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet, Route("Items/{catId?}/{subCatId?}")]
        public IActionResult GetItems(int? catId, int? subCatId = null)
        {
            try
            {
                var categories = home.GetItem(catId, subCatId);
                if (categories != null)
                {
                    return Ok(categories);
                }
                else
                {
                    throw new Exception("Unhandled exception");
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet, Route("getEmergencyInfo/{city}")]
        public IActionResult GetEmergencyInfo(string city)
        {
            try
            {
                var emergencies = home.GetEmergencyInfo(city.Trim());
                if (emergencies != null)
                {
                    return Ok(emergencies);
                }
                return null;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet, Route("getHomeData")]
        public IActionResult GetHomeData()
        {
            try
            {
                var data = home.GetHomeData();
                if (data != null)
                {
                    return Ok(data);
                }
                return null;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost, Route("addItem")]
        public IActionResult AddItem(Item item)
        {
            try
            {
                home.AddItem(item);

                return Ok("{status:'done'}");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}