import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';

import { AuthGuardService } from '../../Shared/Shared/guards/auth-guard.service';
import { AdminGuardService } from '../../Shared/Shared/guards/admin-guard.service';
import { HomeComponent } from './home/home.component';


const routes: Routes = [{
    //canActivate: [AuthGuardService],
    path: '', component: AdminComponent,
    children: [
        { path: '', redirectTo: '/admin/home', pathMatch: 'full' },
        { path: 'home', component: HomeComponent }, /*canActivate: [AdminGuardService]*/
    ]
}

];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AdminRoutingModule { }
