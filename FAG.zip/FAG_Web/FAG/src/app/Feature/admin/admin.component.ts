import { Component, OnInit, ViewChild } from '@angular/core';
import { jqxWindowComponent } from 'jqwidgets-ng/jqxwindow';
declare const $: any;
@Component({
    selector: 'app-admin',
    templateUrl: './admin.component.html',
    styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
    
    constructor() { }
    ngOnInit() {
    }
    ngAfterViewInit() {      
    }
   
}
