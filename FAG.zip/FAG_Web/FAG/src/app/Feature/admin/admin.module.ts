import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { AsideComponent } from '../../Shared/Shared/aside/aside.component';
import { HeaderComponent } from '../../Shared/Shared/header/header.component';

import { ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { BrowserModule } from '@angular/platform-browser';
import { jqxWindowModule } from 'jqwidgets-ng/jqxwindow'
import { jqxTextAreaModule } from 'jqwidgets-ng/jqxtextarea'
import { jqxButtonModule } from 'jqwidgets-ng/jqxbuttons'
import { jqxFileUploadModule } from 'jqwidgets-ng/jqxfileupload'
import { jqxDropDownListModule } from 'jqwidgets-ng/jqxdropdownlist'
@NgModule({
    declarations: [
        AdminComponent,
        HomeComponent,
        
    ],
    imports: [
        CommonModule,
        AdminRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        jqxWindowModule,
        jqxTextAreaModule,
        jqxButtonModule,
        jqxFileUploadModule,
        jqxDropDownListModule
    ]
})
export class AdminModule { }
