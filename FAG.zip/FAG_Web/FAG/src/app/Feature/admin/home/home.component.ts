import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ApiService } from '../../../Services/api.service';
import { Category, SubCategory } from '../../../Shared/classes/home/home';
import { jqxWindowComponent } from 'jqwidgets-ng/jqxwindow';
import { jqxTextAreaComponent } from 'jqwidgets-ng/jqxtextarea';
import { Item, Caution, WhatToDo, Recognition } from '../models/admin.classes';
declare const $: any;
@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    fagItem: Item;
    caution: Caution;
    step: WhatToDo;
    symptom: Recognition;
    @ViewChild('jqxTextArea', { static: false }) myTextArea: jqxTextAreaComponent;
    selectvalue: any = -1;
    selectvalue1: any = -1;
    categories: Category[] = [];
    subCategories: SubCategory[] = [];
    items: [] = [];
    constructor(private apiService: ApiService) {
        this.caution = new Caution();
        this.step = new WhatToDo();
        this.symptom = new Recognition();
        this.fagItem = new Item();
    }
    ngOnInit() {
        this.getCategories();
       
    }
   
    get subCategory() {
        if (this.selectvalue !== -1 && this.selectvalue !== "")
            return this.categories.filter(x => x.id == this.selectvalue)[0].subCategory;
    }
    getCategories() {
        this.apiService.getData<Category[]>("/api/Home/Categories").subscribe(
            data => {
                this.categories = data;
                this.selectvalue = data[0].id;
                this.source = {
                    localdata: this.categories,
                    datatype: 'array',
                    datafields: [
                        { name: 'id' },
                        { name: 'name' }
                    ],
                };
                console.log(this.source);
                this.dataAdapter= new jqx.dataAdapter(this.source);
            },
            error => {

            }
        );
    }
    getSubCategories() {
        this.apiService.getData<SubCategory[]>(`/api/Home/GetSubCategoriesData/${this.selectvalue}`).subscribe(
            data => {
                this.subCategories = data;
                //this.selectvalue = data[0].id;
                this.source1 = {
                    localdata: data,
                    datatype: 'array',
                    datafields: [
                        { name: 'subCatId' },
                        { name: 'subCatName' }
                    ],
                };
                this.dataAdapter1= new jqx.dataAdapter(this.source1);
            },
            error => {

            }
        );
    }
    openModal() {
        
    }
    getItems() {
        this.apiService.getData<any>("/api/Home/AllItems").subscribe(
            data => {
                this.items = data;
            }
            ,
            error => {

            }
        );
    }
    open() {
        
    }
    
    addToList(type) {

        if (type == 1) {
            this.fagItem.Recognitions.push(JSON.parse(JSON.stringify(this.symptom)));
            this.symptom = new Recognition();
        } else
            if (type == 2) {
                this.fagItem.Whattodos.push(JSON.parse(JSON.stringify(this.step)));
                this.step = new WhatToDo();
            }
            else if (type == 3) {
                this.fagItem.Cautions.push(JSON.parse(JSON.stringify(this.caution)));
                this.caution = new Caution();
            }
    }
    saveAll() {
        this.fagItem.Categoryid = this.selectvalue;
        this.fagItem.Subcategoryid = this.selectvalue1;
        this.apiService.postData(`/api/Home/addItem`, this.fagItem).subscribe(res => {
            console.log("done");
            this.fagItem = new Item();
        });
        //console.log(this.fagItem);
    }
    @ViewChild('log', { static: false }) log: ElementRef;
    source: any = {
        localdata: this.categories,
        datatype: 'array'
    };;
    source1: any = {
        localdata: this.categories,
        datatype: 'array'
    };;
    dataAdapter: any = new jqx.dataAdapter(this.source);
    dataAdapter1: any = new jqx.dataAdapter(this.source);
    //listOnSelect(event: any): void {
    //    if (event.args) {
    //        let item = event.args.item;
    //        if (item) {
    //            let valueElement = document.createElement('div');
    //            valueElement.innerHTML = `Value: ${item.value}`;
    //            let labelElement = document.createElement('div');
    //            labelElement.innerHTML = `Label: ${item.label}`;
    //            let selectionLog = this.log.nativeElement;
    //            selectionLog.innerHTML = '';
    //            selectionLog.appendChild(labelElement);
    //            selectionLog.appendChild(valueElement);
    //        }
    //    }
    //};
}
