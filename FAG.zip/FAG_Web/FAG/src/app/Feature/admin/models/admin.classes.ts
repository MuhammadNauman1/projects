﻿export class Item {
    Id: number
    Description: string;
    Categoryid: number;
    Subcategoryid: number;
    Aims: Aim[];
    Cautions: Caution[];
    Images: Image[];
    Videos: Video[];
    Whattodos: WhatToDo[];
    Recognitions: Recognition[];
    constructor() {
        this.Id = -1;
        this.Description = ""
        this.Categoryid = -1;
        this.Subcategoryid - 1;
        this.Aims = [];
        this.Cautions = [];
        this.Images = [];
        this.Videos = [];
        this.Whattodos = [];
        this.Recognitions = [];
    }
}
export class Aim {
    Id=-1;
    Description = "";
    Itemid=-1;
}
export class Caution {
    Id=-1;
    Description="";
    Itemid=-1;
}
export class Video {
    Id=-1;
    Url = "";
    Itemid=-1;
}
export class Image {
    Id=-1;
    Url = "";
}
export class WhatToDo {
    Id=-1;
    Description = "";
    Itemid=-1;
}
export class Recognition {

    Id=-1;
    Description = "";
    Itemid=-1;
}
