import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Category } from '../../../Shared/classes/home/home';
import { ApiService } from '../../../Services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SubCategoryComponent } from './sub-category/sub-category.component';
var $ = require("jquery");
@Component({
    selector: 'app-category',
    templateUrl: './category.component.html',
    styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit,AfterViewInit {
    ngAfterViewInit(): void {
        this.isCatDisplay = true;
    }
    catId = SubCategoryComponent;
    items: any[] = [];
    isCatDisplay = false;
    query = "";
    selectedCategory: Category = new Category();
    selectedSubCategoryId: number = 1;
    categories: Category[] = [];
    SubCategoriesData: any;
    constructor(private apiService: ApiService, private router: ActivatedRoute, private route: Router) { }

    ngOnInit() {
        
        this.initializeRouter();
        this.getCategories();
        $("[id^='cat-']").removeClass("active");
    }
    initializeRouter() {
        this.router.paramMap.subscribe(params => {
            this.selectedCategory.id = parseInt(params.get("id"));
            
            if (params.get("subId") != null && params.get("subId") != undefined) {
                this.getSubCategoriesData(parseInt(params.get("id")), params.get("subId"));
                this.isCatDisplay = false;
            } else {
                this.getItemsSelected(this.selectedCategory.id);
                
            }
        })
    }
    getSubCategoriesData(_catId: number, _subCatId: string) {
        this.apiService.getData<any>(`/api/Home/Items/${_catId}/${_subCatId}`).subscribe(res => {
            this.SubCategoriesData = res;
        },
            exception => {
            });
    }
    getCategories() {
        this.apiService.getData<Category[]>(`/api/Home/Categories`).subscribe(
            data => {
                this.categories = data;
            },
            error => {
            }
        );
    }
    openModal(id) {
        $(`#${id}`).modal("show");

    }

    getItemsSelected(id) {
        if (location.href.indexOf('show') > 0) {
            this.isCatDisplay = false;
        }else
        this.isCatDisplay = true;
        this.apiService.getData<any[]>(`/api/Home/GetSubCategoriesData/${id}`).subscribe(
            data => {
                
                this.items = data;
            }
            ,
            error => {

            }
        );
    }
    navigateToDetail(param1, param2) {
        this.isCatDisplay = false;
        this.route.navigateByUrl(`/category/${param1}/${param2}/show`);
    }
    navigateToCategory(catId) {
        this.isCatDisplay = true;
        this.route.navigateByUrl(`/category/${catId}`);
    }
}
