import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CategoryRoutingModule } from './category-routing.module';
import { CategoryComponent } from './category.component';
import { FormsModule } from '@angular/forms';
import { SubCategoryComponent } from './sub-category/sub-category.component';
import { SubCatDetailComponent } from './sub-cat-detail/sub-cat-detail.component';


@NgModule({
    declarations: [CategoryComponent, SubCategoryComponent, SubCatDetailComponent],
    imports: [
        FormsModule,
        CommonModule,
        CategoryRoutingModule
    ]
})
export class CategoryModule { }
