import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../../Services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from 'jquery'
@Component({
  selector: 'app-sub-cat-detail',
  templateUrl: './sub-cat-detail.component.html',
  styleUrls: ['./sub-cat-detail.component.css']
})
export class SubCatDetailComponent implements OnInit {
    subCatId = null;
    SubCategoriesData: any;
    constructor(private apiService: ApiService, private router: ActivatedRoute, private route: Router) { }

    ngOnInit() {
        
        this.router.paramMap.subscribe(params => {
            debugger
            this.subCatId = params.get('subId');
 
            this.getSubCategoriesData(-1, this.subCatId);
        })
        
  }
    getSubCategoriesData(_catId: number, _subCatId: string) {
        this.apiService.getData<any>(`/api/Home/Items/${-1}/${_subCatId}`).subscribe(res => {
            this.SubCategoriesData = res;
            this.router.parent.params.subscribe(x => {
            })
        },
            exception => {
            });
    }
}
