import { Component, OnInit } from '@angular/core';
import { Category } from '../../../../Shared/classes/home/home';
import { ApiService } from '../../../../Services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from 'jquery';
@Component({
  selector: 'app-sub-category',
  templateUrl: './sub-category.component.html',
  styleUrls: ['./sub-category.component.css']
})
export class SubCategoryComponent implements OnInit {
    isCatDisplay = true;
    selectedCategory: Category = new Category();

    items: any[] = [];

    constructor(private apiService: ApiService, private router: ActivatedRoute, private route: Router) { }

    ngOnInit() {
        this.router.parent.params.subscribe(x => {
            $("[id^='cat-']").removeClass("active");
            this.getItemsSelected(x["id"]);
        })
        this.initializeRouter();
  }
    initializeRouter() {
       
        //this.router.paramMap.subscribe(params => {
        //    debugger
        //    this.selectedCategory.id = parseInt(params.get("id"));
        //    this.getItemsSelected();
        //    //if (params.get("subId") != null && params.get("subId") != undefined) {
        //    //    //this.getSubCategoriesData(parseInt(params.get("id")), params.get("subId"));
        //    //    this.isCatDisplay = false;
        //    //} else {
        //    //    this.isCatDisplay = true;
        //    //    this.getItemsSelected(this.selectedCategory.id);
        //    //}
        //})
    }
    
    getItemsSelected(id) {
        this.apiService.getData<any[]>(`/api/Home/GetSubCategoriesData/${id}`).subscribe(
            data => {
                this.items = data;
            }
            ,
            error => {

            }
        );
    }
}
