import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../Services/api.service';
import { Router } from '@angular/router';

declare const google: any;
//import * as $ from 'jquery';
@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    lat = 51.678418;
    lng = 7.809007;
    self: any;
    emergencyInfo;
    homeData;
    public static currentCity = "";
    constructor(private apiService: ApiService, private router: Router) {
        this.self = this;
    }
    get getCurrentCity() {
        return HomeComponent.currentCity;
    }
    ngOnInit() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((success) => { this.setLocation(success); }, null);
        } else {
            alert('It seems like Geolocation, which is required for this page, is not enabled in your browser. Please use a browser which supports it.');
        }
        this.getHomeData();
    }
    setLocation(success: any) {
        this.lat = success.coords.latitude;
        this.lng = success.coords.longitude;
        var geocoder;
        let _self = this;
        geocoder = new google.maps.Geocoder();
        var latlng = new google.maps.LatLng(success.coords.latitude, success.coords.longitude);
        geocoder.geocode(
            { 'latLng': latlng },
            (results, status) => {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        var add = results[0].formatted_address;
                        var value = add.split(",");

                        let count = value.length;
                        //country = value[count - 1];
                        //state = value[count - 2];
                        //city = value[count - 3];
                        //alert("city name is: " + value[count - 3]);
                        HomeComponent.currentCity = value[count - 3];

                        //$("#city").text(this.currentCity);
                        HomeComponent.currentCity = value[count - 3];
                        _self.getCityEmergencyInfo();
                    }
                    else {
                        alert("address not found");
                    }
                }
                else {
                    alert("Geocoder failed due to: " + status);
                }
            }
        );
    }
    getHomeData() {
        this.apiService.getData(`/api/Home/getHomeData`).subscribe(
            success => {
                this.homeData = success;
            },
            error => {
                console.error(error);
            }
        );
    }
    getCityEmergencyInfo() {
        this.apiService.getData(`/api/Home/getEmergencyInfo/${HomeComponent.currentCity}`).subscribe(
            (success) => {
                this.emergencyInfo = success;
            },
            (error) => {
                console.error(error);
            }
        )
    }
    navigateToCategories(catId) {

        this.router.navigateByUrl('/home/category');
    }
}
