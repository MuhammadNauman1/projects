
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MainComponent } from './main.component';
import { CategoryComponent } from './category/category.component';


const routes: Routes = [
    {
        path: '', component: MainComponent,
        children: [{
            path: '', redirectTo: "/home", pathMatch: 'full'
        },
        {
            path: 'home', component: HomeComponent
        },
            {
                path: 'category/:id', loadChildren: () => import('./category/category.module').then(mod => mod.CategoryModule)
            }
        //    , {
        //    path: 'category/:id/:subId', component: CategoryComponent
        //}
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class MainRoutingModule { }
