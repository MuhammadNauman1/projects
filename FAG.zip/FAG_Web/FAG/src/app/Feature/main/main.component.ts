import { Component, OnInit } from '@angular/core';
import { GlobalValuesService } from '../../services/global-values.service';
import { ApiService } from '../../Services/api.service';
declare const google: any;
import * as $ from 'jquery';
@Component({
    selector: 'app-main',
    templateUrl: './main.component.html',
    styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
    //currentCity: string="";

    constructor(private http: ApiService) {
        //this.http.getData<any>("api/Account/GetUserData").subscribe(
        //    success => {
        //        GlobalValuesService.isAdmin = (success.userType.toUpperCase() == "admin".toUpperCase());
        //        GlobalValuesService.isLoggedIn = true;
        //        GlobalValuesService.FullName = success.firstName + " " + success.lastName;
        //        GlobalValuesService.image = success.image;
        //    },
        //    error => {
        //        if (error == "logout") {
        //            /////location.href = "/#/home";
        //        }
        //    }
        //)
    }
    get isLoggedIn() {
        return GlobalValuesService.isLoggedIn;
    }
    get FullName() {
        return GlobalValuesService.FullName;
    }
    get image() {
        return GlobalValuesService.image;
    }
    ngOnInit() {
        //this.getCurrentLocationInfo();
    }
    //get currentLocationInfo() {
    //    return this.currentCity;
    //}
    //setLocation(success: any) {
    //    var geocoder;
    //    geocoder = new google.maps.Geocoder();
    //    var latlng = new google.maps.LatLng(success.coords.latitude, success.coords.longitude);
    //    let _this = this;
    //    geocoder.geocode(
    //        { 'latLng': latlng },
    //        function (results, status) {
    //            _this.function1(results, status)
    //        }
    //    );
    //}
    //function1(results, status) {
    //    if (status == google.maps.GeocoderStatus.OK) {
    //        if (results[0]) {
    //            var add = results[0].formatted_address;
    //            var value = add.split(",");

    //            let count = value.length;
    //            //country = value[count - 1];
    //            //state = value[count - 2];
    //            //city = value[count - 3];
    //            //alert("city name is: " + value[count - 3]);
    //            this.currentCity = value[count - 3];

    //            $("#city").text(this.currentCity);
    //            this.currentCity = value[count - 3];
    //            //console.log(_this.currentCity);
    //        }
    //        else {
    //            alert("address not found");
    //        }
    //    }
    //    else {
    //        alert("Geocoder failed due to: " + status);
    //    }
    //}
    //getCurrentLocationInfo = () => {
    //    let _this = this;
    //    if (navigator.geolocation) {
    //        navigator.geolocation.getCurrentPosition((success) => { _this.setLocation(success);}, null);
    //    } else {
    //        alert('It seems like Geolocation, which is required for this page, is not enabled in your browser. Please use a browser which supports it.');
    //    }
    //    return "";
    //}
}
