import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { MainRoutingModule } from './main-routing.module';
import { MainComponent } from './main.component';
import { CategoryComponent } from './category/category.component';
import { FormsModule } from '@angular/forms';
import { AgmCoreModule } from '@agm/core'


@NgModule({
    declarations: [MainComponent, HomeComponent],
    imports: [
        CommonModule,
        FormsModule,
        MainRoutingModule,
        AgmCoreModule.forRoot({
            apiKey:'AIzaSyA1On32WMJzaErjXZhvYcEvYDQ_5PvlMCw'
        })
    ]
})
export class MainModule { }
