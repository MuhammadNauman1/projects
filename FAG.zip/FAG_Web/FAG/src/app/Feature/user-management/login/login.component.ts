import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ApiService } from '../../../Services/api.service';
import { GlobalValuesService } from '../../../services/global-values.service';
import { Router } from '@angular/router';
import { User } from '../../../Shared/classes/UserManagement/User';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    model = { Username: "", Password: "" };
    constructor(private apiService: ApiService, private route: Router) { }

    ngOnInit() {
        GlobalValuesService.isAdmin = null;
        GlobalValuesService.isLoggedIn = false;
        GlobalValuesService.FullName = null
        GlobalValuesService.image = null;
    }
    onLoginSubmit(f: NgForm) {
        if (f.invalid) {
            return;
        }
        else {
            this.apiService.postData<User>("/api/Account/Login", f.value).subscribe(
                success => {
                    GlobalValuesService.isAdmin = (success.userType.toUpperCase() == "admin".toUpperCase());
                    GlobalValuesService.isLoggedIn = true;
                    GlobalValuesService.FullName = success.firstName + " " + success.lastName;
                    GlobalValuesService.image = success.image;
                    this.route.navigate(["/home"]);
                },
                error => {
                    console.error(error);
                }
            )
        }
    }
}
