import { Component, OnInit } from '@angular/core';
import { RegisterUserReq } from '../../../Shared/classes/UserManagement/User';
import {  NgForm } from '@angular/forms';
 declare const $:any;
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    model: RegisterUserReq;
    submitted:boolean= false;
  constructor() {
      this.model = new RegisterUserReq();
      //this.model.agreed = true;
  }

  ngOnInit() {
      //$('.i-checks').iCheck({
      //    checkboxClass: 'icheckbox_square-green',
      //    radioClass: 'iradio_square-green',
      //});
      //$("#agreed").attr("checked", false);
      this.submitted = false;
  }
    onSubmit(f: NgForm) {
        alert("dsf")
        //alert(JSON.stringify(f.value));
        this.submitted = true;
    }
}
