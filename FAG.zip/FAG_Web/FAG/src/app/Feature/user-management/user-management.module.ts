import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserMainComponent } from './main.component';
import { UserRoutingModule } from './user-routing.module';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { jqxInputModule } from 'jqwidgets-ng/jqxinput';
import { jqxPasswordInputModule } from 'jqwidgets-ng/jqxpasswordinput';
import { jqxButtonModule } from 'jqwidgets-ng/jqxbuttons';
import { jqxCheckBoxModule } from 'jqwidgets-ng/jqxcheckbox';



@NgModule({
    declarations: [UserMainComponent, LoginComponent, RegisterComponent],
    imports: [

        FormsModule,
        CommonModule,
        UserRoutingModule,
        jqxInputModule,
        jqxPasswordInputModule,
        jqxButtonModule,
        jqxCheckBoxModule
    ]
})
export class UserManagementModule { }
