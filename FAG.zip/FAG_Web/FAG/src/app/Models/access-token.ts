class AccessToken {
    accessToken: string;
    expiration: string;
    refreshToken: string;
}