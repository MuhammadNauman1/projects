﻿export class login {
    public Email: string;
    public Password: string;
}

export class Signup {

    public Trainee_ID: number;
    public Username: string;
    public Password: string;
    public RepeatPassword: string;
    public First_Name: string;
    public Last_Name: string;
    public CNIC: string;
    public Gender: string;
    public Contact_Number: string;
    public Office_ID: string;
    public Deleted: boolean;
    public Created_By: string;
    public Created_Date: Date;
    public Modified_By: string;
    public Email: string;
    public Modified_Date: Date;
}


