
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { login, Signup } from '../models/user-managment';
import { HttpClient, HttpHeaders, HttpEventType, HttpRequest } from '@angular/common/http';
import { GlobalValuesService } from './global-values.service';
import { VideoRequestModel } from '../Models/Videos/request.classes';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ApiService {
    constructor(private http: HttpClient) { }
    postData<T>(url:string,data:any):Observable<T>{
        return this.http.post<T>(url,data);
    }
    getData<T>(url:string):Observable<T>{
        return this.http.get<T>(url);
    }
    
   
}
