import { Injectable } from '@angular/core';

@Injectable({
    providedIn: "root"
})
export class GlobalValuesService {
    constructor() {
    }
    static accessToken: string;
    static expiration: string;
    static refreshToken: string;
    static isLoggedIn: boolean = false;
    static isAdmin: boolean = false;
    static FullName: string = "";
    static image: string = "";
    static catid: number=-1;
}
