import { Injectable } from '@angular/core';
import { CanActivate,ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { GlobalValuesService } from '../../../services/global-values.service';

@Injectable({
  providedIn: 'root'
})
export class AdminGuardService implements CanActivate {

    constructor(private _router: Router) { }
    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
        if (!GlobalValuesService.isAdmin) {
            this._router.navigate(["/home"]);
            return false;
        }
        return true;
    }
}
