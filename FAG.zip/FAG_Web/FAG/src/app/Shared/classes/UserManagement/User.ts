﻿export class User {
    id: number;
    firstName: string;
    lastName: string;
    username: string;
    password: string;
    userType: string;
    image: string;
}
export class RegisterUserReq {
    id: number;
    firstName: string;
    lastName: string;
    username: string;
    password: string;
    userType: string;
    agreed: boolean;
}