﻿export class Category {
    public id: number;
    public name: string;
    public subCategory: SubCategory;
}
export class SubCategory {
    public id: number;
    public name: string;
    public categoryid: number;
}