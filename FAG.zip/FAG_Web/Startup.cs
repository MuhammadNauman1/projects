﻿using System;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using FAG_Web.Core.Entities;
using FAG_Web.Core.Interfaces.Account;
using FAG_Web.Core.Managers.Account;
using Microsoft.Extensions.FileProviders;
using Microsoft.AspNetCore.Http;
using FAG_Web.Core.Interfaces.Home;
using FAG_Web.Core.Managers.Home;

namespace FAG_Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
            //    services.AddDbContext<AppDbContext>(options =>
            //options.UseSqlServer(Configuration.GetConnectionString("EmpConnectionString")));

            //    services.AddDbContext<AppDbContext>(options =>
            //    {
            //        options.UseInMemoryDatabase("jwtapi");
            //    });

            //    services.AddScoped<IUserRepository, UserRepository>();
            //    services.AddScoped<IUnitOfWork, UnitOfWork>();

            //    services.AddSingleton<IPasswordHasher, PasswordHasher>();
            //    services.AddSingleton<ITokenHandler, TokenHandler>();

            //    services.AddScoped<IUserService, UserService>();
            //    services.AddScoped<IAuthenticationService, AuthenticationService>();

            services.AddDbContext<FAG_CONTEXT>(options => {
                options.UseSqlServer(Configuration.GetConnectionString("EmpConnectionString"));
            });
            services.AddDbContext<FAG_CONTEXT>(options =>
            {
                options.UseInMemoryDatabase("jwtapi");
            });
            AddScopes(ref services);
            services.AddSession(options =>
            {
                options.Cookie.Name = ".AdventureWorks.Session";
                options.IdleTimeout = TimeSpan.FromMinutes(10);
                options.Cookie.IsEssential = true;
            });




            //services.Configure<Security.Tokens.TokenOptions>(Configuration.GetSection("TokenOptions"));
            //var tokenOptions = Configuration.GetSection("TokenOptions").Get<Security.Tokens.TokenOptions>();
            //services.Configure<TokenOptions>(Configuration.GetSection("TokenOptions"));
            //var tokenOptions= Configuration.GetSection("TokenOptions").Get<TokenOptions>();
            //var signingConfigurations = new SigningConfigurations();
            //services.AddSingleton(signingConfigurations);

            //services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            //    .AddJwtBearer(jwtBearerOptions =>
            //    {
            //        jwtBearerOptions.TokenValidationParameters = new TokenValidationParameters()
            //        {
            //            ValidateAudience = true,
            //            ValidateLifetime = true,
            //            ValidateIssuerSigningKey = true,
            //            ValidIssuer = tokenOptions.Issuer,
            //            ValidAudience = tokenOptions.Audience,
            //            IssuerSigningKey = signingConfigurations.Key,
            //            ClockSkew = TimeSpan.Zero
            //        };
            //    });
            //services.AddAutoMapper();
            services.AddDistributedMemoryCache();


            services.AddMvc();
          
        }

      

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            
            app.UseStaticFiles();
            //app.UseCookiePolicy();
            app.UseSession();
            app.UseMvc();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
            app.UseFileServer(new FileServerOptions {
               FileProvider=new PhysicalFileProvider("D:\\files"),
               RequestPath=new PathString("/files"),
               EnableDirectoryBrowsing=true
            });
            
            //app.UseEndpoints(endpoints =>
            //{
            //    endpoints.MapControllers();
            //});


        }

        #region Add Your Interface And Its implementation class here to avoid activation exception
        private void AddScopes(ref IServiceCollection services)
        {
            services.AddScoped<IAccount, Account>();
            services.AddScoped<IHome, Home>();
            //services.AddScoped<IUserRepository, UserRepository>();
            //services.AddScoped<IUnitOfWork, UnitOfWork>();

            //services.AddSingleton<Core.Core.Security.Hashing.IPasswordHasher, PasswordHasher>();
            //services.AddSingleton<Core.Core.Security.Tokens.ITokenHandler, TokenHandler>();

            //services.AddScoped<FAG_Web.Core.Core.Services.IUserService, FAG_Web.Core.Services.UserService>();
            //services.AddScoped<FAG_Web.Core.Core.Services.IAuthenticationService, AuthenticationService>();
            //services.AddScoped<IUserManagement, UserManagement>();
            //services.AddScoped<IVideoManager, VideoManager>();
        }
        #endregion









    }
}








