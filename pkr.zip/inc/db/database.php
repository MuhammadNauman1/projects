<?php
$conn=mysqli_connect($host,$username,$password,$db);
?>