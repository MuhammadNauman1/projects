
<?php
session_start();
if(empty($_SESSION["user"])){
	header("Location: ./login.php");
}
include_once './inc/config/db.config.php';
include_once './inc/db/database.php';
$query = "select * from visitors";
$result = $conn->query($query);
echo json_decode($result);
?>
